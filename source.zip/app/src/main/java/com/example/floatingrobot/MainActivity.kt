package com.example.floatingrobot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "Floating Robot"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Aktifkan izin tampil di atas aplikasi lain, lalu mulai robot mengambang."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }
        val permission = Button(this).apply {
            text = "Aktifkan izin mengambang"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startRobot()
                }
            }
        }
        val start = Button(this).apply {
            text = "Mulai / tampilkan robot"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startRobot()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val stop = Button(this).apply {
            text = "Hentikan robot"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) }
        }
        root.addView(title, ViewGroup.LayoutParams(-1, -2))
        root.addView(info, ViewGroup.LayoutParams(-1, -2))
        root.addView(permission)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun startRobot() {
        startService(Intent(this, FloatingService::class.java))
    }

    override fun onResume() {
        super.onResume()
        // Permission is checked again when the user taps Start.
    }
}
