package com.example.floatingrobot

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import android.graphics.drawable.GradientDrawable

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var robot: ImageView? = null
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showRobot()
    }

    private fun showRobot() {
        if (robot != null) return
        val image = ImageView(this).apply {
            setImageResource(R.drawable.robot)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Robot mengambang. Ketuk untuk membuka menu."
            setOnClickListener { togglePanel() }
        }
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        params = WindowManager.LayoutParams(
            dp(116), dp(150), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(140)
        }

        image.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX; downY = event.rawY
                        startX = params.x; startY = params.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                        params.x = startX + dx
                        params.y = startY + dy
                        try { wm.updateViewLayout(image, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        })
        robot = image
        wm.addView(image, params)
    }

    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val card = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(0xF21B2540.toInt())
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFF35D6E8.toInt())
            }
        }
        val heading = android.widget.TextView(this).apply {
            text = "🤖 Robot AI"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val body = android.widget.TextView(this).apply {
            text = "Robot mengambang aktif. Untuk bantuan belajar, buka aplikasi dan masukkan soal latihan."
            textSize = 14f
            setTextColor(0xFFE8F4FF.toInt())
            setPadding(0, dp(8), 0, dp(8))
        }
        val close = android.widget.Button(this).apply {
            text = "Tutup"
            setOnClickListener { togglePanel() }
        }
        card.addView(heading)
        card.addView(body)
        card.addView(close)
        val p = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = params.x + dp(70)
            y = params.y + dp(40)
        }
        panel = card
        wm.addView(card, p)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        robot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        robot = null
        super.onDestroy()
    }
}
