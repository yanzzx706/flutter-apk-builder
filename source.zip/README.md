# Floating Robot (Android Studio)

Proyek Android dasar untuk menampilkan gambar robot pengguna sebagai overlay mengambang transparan.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `FloatingRobot` melalui Android Studio.
3. Tunggu Gradle Sync, lalu Build > Build APK(s).
4. Instal APK di perangkat Android.
5. Buka aplikasi, aktifkan izin "Tampil di atas aplikasi lain", lalu tekan "Mulai / tampilkan robot".

Robot bisa digeser dan diketuk. Menu kecil saat diketuk saat ini hanya berupa panel status; belum terhubung ke layanan AI/OCR.
Untuk membuat integrasi AI, diperlukan backend/API dan izin serta desain privasi tambahan.

Catatan: proyek sumber ini bukan APK siap instal. Build dilakukan di Android Studio.
